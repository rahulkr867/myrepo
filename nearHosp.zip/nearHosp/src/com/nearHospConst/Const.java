package com.nearHospConst;

public class Const {
	public static String slogan="\"To Provide Information about Nearest Hospital\"";
}
