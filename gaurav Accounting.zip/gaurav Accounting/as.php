<?php
session_start();
$con=mysqli_connect("localhost","root","","db");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  $query=$_POST['query'];
 // $_SESSION['queries']=$query;
    $sql = "SELECT * FROM stock WHERE p_name='$query'";
  if ($result=mysqli_query($con,$sql))
  {
  // Return the number of rows in result set
  $rowcount=mysqli_num_rows($result);
  //printf("Result set has %d rows.\n",$rowcount);
  // Free result set
  mysqli_free_result($result);
  }
  if($rowcount>0)
  { $_SESSION['queries']=$query;
	  header('location: search.php');}
  else
  {header('location:error.html');}
mysqli_close($con);
?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title></title>
    </head>
    <body>

    </body>
</html>
