<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo'<b>"Your Data has been Stored:"</>'."<br>";
echo '<body style="background-color:silver"></body>';

$v3 =$_POST['a'];
$v4 =$_POST['b'];
$v5 =$_POST['c'];
$v6 =$_POST['d'];
$v28 =$v6*$v5;
$v7 =$_POST['e'];


$v8 =$_POST['a1'];
$v9 =$_POST['a2'];
$v10 =$_POST['a3'];
$v11 =$_POST['a4'];
$v31 =$v10*$v11;
$v12 =$v7;


$v13 =$_POST['b1'];
$v14 =$_POST['b2'];
$v15 =$_POST['b3'];
$v16 =$_POST['b4'];
$v34 =$v15*$v16;
$v17 =$v7;


$v18 =$_POST['c1'];
$v19 =$_POST['c2'];
$v20 =$_POST['c3'];
$v21 =$_POST['c4'];
$v37 =$v20*$v21;
$v22 =$v7;

$v23 =$_POST['i1'];
$v24 =$_POST['i2'];
$v25 =$_POST['i3'];
$v26 =$_POST['i4'];
$v40 =$v25*$v26;
$v27 =$v7;


if($v3>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v3 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g1=$row["p_qty"];
   if($g1>$v5)
     {  $v30="AVAILABLE";
        $sql = "CALL product($v3,'$v4',$v5,$v6,$v28,CURDATE(),'$v30',$v7);";
        $sql .= "CALL uqty($v3,($g1-$v5));";
        $sql .="CALL updatedorderid($v7)";
        if (mysqli_multi_query($conn, $sql)) {
            do {

                if ($result = mysqli_store_result($conn)) {
                    while ($row = mysqli_fetch_row($result)) {
                        printf("%s\n", $row[0]);
                    }
                    mysqli_free_result($result);
                }

                if (mysqli_more_results($conn)) {
                    printf("\n");
                }
            } while (mysqli_next_result($conn));
        }

     }
  else {
    echo '<script language="javascript">';
    echo 'alert("Product 1 not AVAILABLE")';
    echo '</script>';
/*    $v30="NOT AVAILABLE";
    $v5=$v6=$v28=0;
    $sql = "CALL product($v3,'$v4',$v5,$v6,$v28,CURDATE(),'$v30',$v7);";
    if ($conn->query($sql) === TRUE) {
          }
}*/
}



if($v8>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v8 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g2=$row["p_qty"];
if($g2>$v10)
  {  $v33="AVAILABLE";
     $sql = "CALL product($v8,'$v9',$v10,$v11,$v31,CURDATE(),'$v33',$v12);";
     $sql .= "CALL uqty($v8,($g2-$v10))";
     if (mysqli_multi_query($conn, $sql)) {
         do {

             if ($result = mysqli_store_result($conn)) {
                 while ($row = mysqli_fetch_row($result)) {
                     printf("%s\n", $row[0]);
                 }
                 mysqli_free_result($result);
             }

             if (mysqli_more_results($conn)) {
                 printf("\n");
             }
         } while (mysqli_next_result($conn));
     }

  }
else {
  echo '<script language="javascript">';
  echo 'alert("Product 2 not AVAILABLE")';
  echo '</script>';
 /*$v33="NOT AVAILABLE";
 $v10=$v11=$v31=0;
 $sql = "CALL product($v8,'$v9',$v10,$v11,$v31,CURDATE(),'$v33',$v12);";
 if ($conn->query($sql) === TRUE) {
       }
}*/
}










if($v13>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v13 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g3=$row["p_qty"];
if($g3>$v15)
  {  $v36="AVAILABLE";
     $sql = "CALL product($v13,'$v14',$v15,$v16,$v34,CURDATE(),'$v36',$v17);";
     $sql .= "CALL uqty($v13,($g3-$v15))";
     if (mysqli_multi_query($conn, $sql)) {
         do {

             if ($result = mysqli_store_result($conn)) {
                 while ($row = mysqli_fetch_row($result)) {
                     printf("%s\n", $row[0]);
                 }
                 mysqli_free_result($result);
             }

             if (mysqli_more_results($conn)) {
                 printf("\n");
             }
         } while (mysqli_next_result($conn));
     }

  }
else {
  echo '<script language="javascript">';
  echo 'alert("Product 3 not AVAILABLE")';
  echo '</script>';
 /*$v36="NOT AVAILABLE";
 $v16=$v15=$v34=0;
 $sql = "CALL product($v13,'$v14',$v15,$v16,$v34,CURDATE(),'$v36',$v17);";
 if ($conn->query($sql) === TRUE) {
       }
}*/
}







if($v18>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v18";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g4=$row["p_qty"];
if($g4>$v20)
  {  $v39="AVAILABLE";
     $sql = "CALL product($v18,'$v19',$v20,$v21,$v37,CURDATE(),'$v39',$v22);";
     $sql .= "CALL uqty($v18,($g4-$v20))";
     if (mysqli_multi_query($conn, $sql)) {
         do {

             if ($result = mysqli_store_result($conn)) {
                 while ($row = mysqli_fetch_row($result)) {
                     printf("%s\n", $row[0]);
                 }
                 mysqli_free_result($result);
             }

             if (mysqli_more_results($conn)) {
                 printf("\n");
             }
         } while (mysqli_next_result($conn));
     }

  }
else {
  echo '<script language="javascript">';
  echo 'alert("Product 4 not AVAILABLE")';
  echo '</script>';
 /*$v39="NOT AVAILABLE";
 $v20=$v21=$v37=0;
 $sql = "CALL product($v18,'$v19',$v20,$v21,$v37,CURDATE(),'$v39',$v22);";
 if ($conn->query($sql) === TRUE) {
       }
}*/
}







if($v23>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v23 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g5=$row["p_qty"];

if($g5>$v25)
  {  $v42="AVAILABLE";
     $sql = "CALL product($v23,'$v24',$v25,$v26,$v40,CURDATE(),'$v42',$v27);";
     $sql .= "CALL uqty($v23,($g5-$v25))";
     if (mysqli_multi_query($conn, $sql)) {
         do {

             if ($result = mysqli_store_result($conn)) {
                 while ($row = mysqli_fetch_row($result)) {
                     printf("%s\n", $row[0]);
                 }
                 mysqli_free_result($result);
             }

             if (mysqli_more_results($conn)) {
                 printf("\n");
             }
         } while (mysqli_next_result($conn));
     }

  }
else {
  echo '<script language="javascript">';
  echo 'alert("Product 1 not AVAILABLE")';
  echo '</script>';/*
 $v42="NOT AVAILABLE";
 $v25=$v40=$v26=0;
 $sql = "CALL product($v23,'$v24',$v25,$v26,$v40,CURDATE(),'$v42',$v27);";
 if ($conn->query($sql) === TRUE) {
       }
}*/
}

mysqli_close($conn);

?>
 <form method="post" action="index.html"style="position: absolute; top: 550px; right: 45px; width: 100px;height: 25px; text-align:right;">
     <button type="submit">Back to Homepage</button>
</form>

<form method="post" action="billing.html" style="position: absolute; top: 550px; right: 143px; width: 100px;height: 25px; text-align:right;">
    <button type="submit">Back to Billing</button>
</form>
<form method="post" action="billtable.php" style="position: absolute; top: 550px; right: 255px; width: 100px;height: 25px; text-align:right;">
     <input type="submit" value="View your Billing">
</form>
