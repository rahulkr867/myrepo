<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//echo"great"."<br>";

$v3 =$_POST['email'];
$v4 =$_POST['pass'];

$sql = "select password from `sign up` where `email id`='$v3'";
$result = mysqli_query($conn,$sql);
$row = mysqli_fetch_assoc($result);
//echo $row['password'];
if($v4==$row['password'])
{
	header('Location:index.html');
}
 else {
    echo "invalid id or password ";
}
$conn->close();
?>
