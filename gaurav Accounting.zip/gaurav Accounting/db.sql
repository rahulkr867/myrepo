-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 17, 2016 at 09:30 PM
-- Server version: 10.1.10-MariaDB
-- PHP Version: 5.6.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `prod` (IN `P` INT(5), IN `C` INT(5), IN `Q` INT(5), IN `SP` INT(5), IN `NAME` VARCHAR(50), IN `OID` INT(5))  INSERT INTO order_info VALUES(P,C,NAME,Q,SP,30,CURRENT_DATE,"NO",OID)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `product` (IN `P` INT, IN `NAME` VARCHAR(50), IN `Q` INT, IN `SP` INT, IN `TOTAL` INT, IN `SDATE` DATE, IN `OOS` VARCHAR(50), IN `OID` INT)  INSERT INTO order_info VALUES(P,NAME,Q,SP,TOTAL,SDATE,OOS,OID)$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updatedorderid` (IN `id` INT)  NO SQL
UPDATE `orderidupdate` SET `serial`=1,`updatedid`=id WHERE serial=1$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `uqty` (IN `p` INT(5), IN `uqty` INT(5))  NO SQL
UPDATE `stock` SET p_qty=uqty WHERE p_id=p$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `billing`
--

CREATE TABLE `billing` (
  `customer_id` int(11) NOT NULL,
  `bill_date` date NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orderidupdate`
--

CREATE TABLE `orderidupdate` (
  `serial` int(11) NOT NULL,
  `updatedid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orderidupdate`
--

INSERT INTO `orderidupdate` (`serial`, `updatedid`) VALUES
(1, 322);

-- --------------------------------------------------------

--
-- Table structure for table `order_info`
--

CREATE TABLE `order_info` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `qty` int(11) NOT NULL,
  `selling_price` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `sell_date` date NOT NULL,
  `out of stock status` varchar(50) NOT NULL,
  `order_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_info`
--

INSERT INTO `order_info` (`product_id`, `product_name`, `qty`, `selling_price`, `total`, `sell_date`, `out of stock status`, `order_id`) VALUES
(1, 'p2', 120, 150, 18000, '2016-04-17', 'AVAILABLE', 256),
(101, 'P1', 122, 152, 18544, '2016-04-17', 'AVAILABLE', 322);

-- --------------------------------------------------------

--
-- Table structure for table `sales on given date`
--

CREATE TABLE `sales on given date` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `net_profit` int(11) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sign up`
--

CREATE TABLE `sign up` (
  `first name` varchar(50) NOT NULL,
  `last name` varchar(50) NOT NULL,
  `email id` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sign up`
--

INSERT INTO `sign up` (`first name`, `last name`, `email id`, `password`) VALUES
('d', 's', 'a@gmail.com', '12345'),
('gaurav', 'rungta', 'gauravrungta1234@gmail.com', '1234'),
('gaurav', 'rungta', 'gauravrungta123@gmail.com', '123'),
('Gurupriy', 'Inamdar', 'gurupriy04@gmail.com', 'gurupriy'),
('q', 'q', 'q@gmail.com', '1'),
('hhhh', 'eeee', 'rrr@gmail.com', '123321');

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

CREATE TABLE `stock` (
  `p_id` int(11) NOT NULL,
  `p_qty` int(11) NOT NULL,
  `cost price` int(11) NOT NULL,
  `selling price` int(11) NOT NULL,
  `net_profit` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `p_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`p_id`, `p_qty`, `cost price`, `selling price`, `net_profit`, `purchase_date`, `p_name`) VALUES
(0, 0, 0, 0, 0, '2016-04-17', ''),
(1, 336, 5, 7, 2, '2016-04-17', 'p1'),
(1, 336, 255, 633, 378, '2016-04-17', 'p2'),
(101, 532, 123, 152, 29, '2016-04-17', 'p1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `order_info`
--
ALTER TABLE `order_info`
  ADD KEY `product_id` (`product_id`),
  ADD KEY `product_name` (`product_name`);

--
-- Indexes for table `sign up`
--
ALTER TABLE `sign up`
  ADD PRIMARY KEY (`email id`,`password`);

--
-- Indexes for table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`p_id`,`p_name`),
  ADD KEY `p_name` (`p_name`),
  ADD KEY `p_id` (`p_id`),
  ADD KEY `p_name_2` (`p_name`),
  ADD KEY `p_name_3` (`p_name`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_info`
--
ALTER TABLE `order_info`
  ADD CONSTRAINT `order_product_id` FOREIGN KEY (`product_id`) REFERENCES `stock` (`p_id`),
  ADD CONSTRAINT `order_product_id1` FOREIGN KEY (`product_name`) REFERENCES `stock` (`p_name`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
