<?php


$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//echo"great"."<br>";
$v3 =$_POST['fname'];
$v4 =$_POST['name'];
$v5 =$_POST['email'];
$v6 =$_POST['pass'];
$sql = "INSERT INTO `sign up` VALUES ('$v3', '$v4', '$v5','$v6')";

if ($conn->query($sql) === TRUE) {
   header('Location:http://localhost:1080/project/index.html');
} else {
    echo "EMAIL ID ALREADY REGISTERED";
}

$conn->close();
?>
