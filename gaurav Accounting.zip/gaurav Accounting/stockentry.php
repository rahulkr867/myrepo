<html>
<title>Stock Entry</title>
</html>
<?php

echo"lsaura<br>";
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//echo'<b>"Your Data has been Stored:"</>'."<br>";
echo '<body style="background-color:silver"></body>';
$v3 =$_POST['a'];
$v4 =$_POST['e'];
$v5 =$_POST['c'];
$v6 =$_POST['d'];
$v66=$v6-$v5;
$v7 =$_POST['b'];


$v8 =$_POST['a1'];
$v9 =$_POST['a5'];
$v10 =$_POST['a3'];
$v11 =$_POST['a4'];
$v67=$v11-$v10;
$v12 =$_POST['a2'];



$v13 =$_POST['b1'];
$v14 =$_POST['b5'];
$v15 =$_POST['b3'];
$v16 =$_POST['b4'];
$v69=$v16-$v15;
$v17 =$_POST['b2'];


$v18 =$_POST['c1'];
$v19 =$_POST['c5'];
$v20 =$_POST['c3'];
$v21 =$_POST['c4'];
$v70=$v21-$v20;
$v22 =$_POST['c2'];


$v23 =$_POST['i1'];
$v24 =$_POST['i5'];
$v25 =$_POST['i3'];
$v26 =$_POST['i4'];
$v71=$v26-$v25;
$v27 =$_POST['i2'];






$sql =  "Insert into Stock value('$v3','$v4','$v5','$v6','$v66',CURDATE(),'$v7');";

$sql .= "Insert into Stock value('$v8','$v9','$v10','$v11','$v67',CURDATE(),'$v12');";
$sql .= "Insert into Stock value('$v13','$v14','$v15','$v16','$v69',CURDATE(),'$v17');";

$sql .= "Insert into Stock value('$v18','$v19','$v20','$v21','$v70',CURDATE(),'$v22');";
/*$sql .= "Insert into Stock ($_POST['d1'],$_POST['d2'],$_POST['d3'],$_POST['d4'],$_POST['d5']);";
$sql .= "Insert into Stock ('$_POST['e1']','$_POST['e2']','$_POST['e3']','$_POST['e4']','$_POST['e5']');";
$sql .= "Insert into Stock ('$_POST['f1']','$_POST['f2']','$_POST['f3']','$_POST['f4']','$_POST['f5']');";
$sql .= "Insert into Stock ('$_POST['g1']','$_POST['g2']','$_POST['g3']','$_POST['g4']','$_POST['g5']');";
$sql .= "Insert into Stock ('$_POST['h1']','$_POST['h2']','$_POST['h3']','$_POST['h4']','$_POST['h5']');";*/
$sql .= "Insert into Stock value('$v23','$v24','$v25','$v26','$v71',CURDATE(),'$v27' )";

/* execute multi query */
if (mysqli_multi_query($conn, $sql)) {
    do {

        if ($result = mysqli_store_result($conn)) {
            while ($row = mysqli_fetch_row($result)) {
                printf("%s\n", $row[0]);
            }
            mysqli_free_result($result);
        }

        if (mysqli_more_results($conn)) {
            printf("\n");
        }
    } while (mysqli_next_result($conn));
}

if ($conn->query($sql) === TRUE) {
   header('Location: index.html');
} else {
  header('Location: ./datasubmit/index.html');
}




mysqli_close($conn);

?>
