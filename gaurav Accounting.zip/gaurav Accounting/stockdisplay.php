<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 {
    width: 100%;
    background-color: #f1f1c1;
}
</style>
</head>
<body>



<table id="t01">
  <tr>
    <th>Product Id</th>
    <th>Product Name</th>
    <th>Cost price</th>
    <th>Selling price</th>
	  <th>Profit</th>
    <th>Purchase date</th>
	  <th>Quantity</th>

  </tr>
  <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";


$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
    <?php

$sql = "SELECT * FROM stock ";
$result = mysqli_query($conn, $sql);
    ?>
<?php  if(mysqli_num_rows($result)>0)?>
<?php {
    ?>


   <?php  while($row = mysqli_fetch_assoc($result))
    {?>
     <?php   if($row["p_id"]){?>
        <tr>
    <td><?php  echo $row["p_id"]; ?></td>
    <td><?php echo $row["p_name"]; ?></td>
    <td><?php echo $row["cost price"]; ?></td>
    <td><?php echo $row["selling price"]; ?></td>
	<td><?php echo $row["net_profit"]; ?></td>
	<td><?php echo $row["purchase_date"]; ?></td>
	<td><?php echo $row["p_qty"]; ?></td>

	<?php	}?>
 </tr>


   <?php } ?>
  </table>
<?php } ?>

<?php mysqli_close($conn);

?>


</body>
</html>
