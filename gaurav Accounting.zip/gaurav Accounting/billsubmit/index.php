<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$v3 =$_POST['a'];
$v4 =$_POST['b'];
$v5 =$_POST['c'];
$v6 =$_POST['d'];
$v28 =$v6*$v5;
$v7 =$_POST['e'];


$v8 =$_POST['a1'];
$v9 =$_POST['a2'];
$v10 =$_POST['a3'];
$v11 =$_POST['a4'];
$v31 =$v10*$v11;
$v12 =$v7;


$v13 =$_POST['b1'];
$v14 =$_POST['b2'];
$v15 =$_POST['b3'];
$v16 =$_POST['b4'];
$v34 =$v15*$v16;
$v17 =$v7;


$v18 =$_POST['c1'];
$v19 =$_POST['c2'];
$v20 =$_POST['c3'];
$v21 =$_POST['c4'];
$v37 =$v20*$v21;
$v22 =$v7;

$v23 =$_POST['i1'];
$v24 =$_POST['i2'];
$v25 =$_POST['i3'];
$v26 =$_POST['i4'];
$v40 =$v25*$v26;
$v27 =$v7;

if($v3>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v3 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g1=$row["p_qty"];
   if($g1>$v5)
     {  $v30="AVAILABLE";
        $sql = "CALL product($v3,'$v4',$v5,$v6,$v28,CURDATE(),'$v30',$v7);";
        $sql .= "CALL uqty($v3,($g1-$v5));";
        $sql .="CALL updatedorderid($v7)";
        if (mysqli_multi_query($conn, $sql)) {
            do {

                if ($result = mysqli_store_result($conn)) {
                    while ($row = mysqli_fetch_row($result)) {
                        printf("%s\n", $row[0]);
                    }
                    mysqli_free_result($result);
                }

                if (mysqli_more_results($conn)) {
                    printf("\n");
                }
            } while (mysqli_next_result($conn));
        }

     }
  else {
  echo '<script type="text/javascript">';
  echo 'alert("Product 1 Not Available");';
  echo '</script>';

      $v30="NOT AVAILABLE";
    $v5=$v6=$v28=0;
    $sql = "CALL product($v3,'$v4',$v5,$v6,$v28,CURDATE(),'$v30',$v7);";
    if ($conn->query($sql) === TRUE) {
          }
$sql="CALL updatedorderid($v7)";
if ($conn->query($sql) === TRUE) {
      }

}
}



if($v8>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v8 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g2=$row["p_qty"];
if($g2>$v10)
  {  $v33="AVAILABLE";
     $sql = "CALL product($v8,'$v9',$v10,$v11,$v31,CURDATE(),'$v33',$v12);";
     $sql .= "CALL uqty($v8,($g2-$v10))";
     if (mysqli_multi_query($conn, $sql)) {
         do {

             if ($result = mysqli_store_result($conn)) {
                 while ($row = mysqli_fetch_row($result)) {
                     printf("%s\n", $row[0]);
                 }
                 mysqli_free_result($result);
             }

             if (mysqli_more_results($conn)) {
                 printf("\n");
             }
         } while (mysqli_next_result($conn));
     }

  }
else {
echo '<script type="text/javascript">';
echo 'alert("Product 2 Not Available");';
echo '</script>';
$flag=1;

 $v33="NOT AVAILABLE";
 $v10=$v11=$v31=0;
 $sql = "CALL product($v8,'$v9',$v10,$v11,$v31,CURDATE(),'$v33',$v12);";
 if ($conn->query($sql) === TRUE) {
       }
       $sql="CALL updatedorderid($v7)";
       if ($conn->query($sql) === TRUE) {
             }

}

}










if($v13>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v13 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g3=$row["p_qty"];
if($g3>$v15)
  {  $v36="AVAILABLE";
     $sql = "CALL product($v13,'$v14',$v15,$v16,$v34,CURDATE(),'$v36',$v17);";
     $sql .= "CALL uqty($v13,($g3-$v15))";
     if (mysqli_multi_query($conn, $sql)) {
         do {

             if ($result = mysqli_store_result($conn)) {
                 while ($row = mysqli_fetch_row($result)) {
                     printf("%s\n", $row[0]);
                 }
                 mysqli_free_result($result);
             }

             if (mysqli_more_results($conn)) {
                 printf("\n");
             }
         } while (mysqli_next_result($conn));
     }

  }
else {
echo '<script type="text/javascript">';
echo 'alert("Product 3 Not Available");';
echo '</script>';

$flag=1;

 $v36="NOT AVAILABLE";
 $v16=$v15=$v34=0;
 $sql = "CALL product($v13,'$v14',$v15,$v16,$v34,CURDATE(),'$v36',$v17);";
 if ($conn->query($sql) === TRUE) {
       }
       $sql="CALL updatedorderid($v7)";
       if ($conn->query($sql) === TRUE) {
             }

}
}







if($v18>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v18";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g4=$row["p_qty"];
if($g4>$v20)
  {  $v39="AVAILABLE";
     $sql = "CALL product($v18,'$v19',$v20,$v21,$v37,CURDATE(),'$v39',$v22);";
     $sql .= "CALL uqty($v18,($g4-$v20))";
     if (mysqli_multi_query($conn, $sql)) {
         do {

             if ($result = mysqli_store_result($conn)) {
                 while ($row = mysqli_fetch_row($result)) {
                     printf("%s\n", $row[0]);
                 }
                 mysqli_free_result($result);
             }

             if (mysqli_more_results($conn)) {
                 printf("\n");
             }
         } while (mysqli_next_result($conn));
     }

  }
else {
  echo '<script type="text/javascript">';
echo 'alert("Product 4 Not Available");';
echo '</script>';
$flag=1;

 $v39="NOT AVAILABLE";
 $v20=$v21=$v37=0;
 $sql = "CALL product($v18,'$v19',$v20,$v21,$v37,CURDATE(),'$v39',$v22);";
 if ($conn->query($sql) === TRUE) {
       }
       $sql="CALL updatedorderid($v7)";
       if ($conn->query($sql) === TRUE) {
             }

}
}







if($v23>0)
{
$sql = "SELECT p_qty FROM stock WHERE p_id=$v23 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g5=$row["p_qty"];

if($g5>$v25)
  {  $v42="AVAILABLE";
     $sql = "CALL product($v23,'$v24',$v25,$v26,$v40,CURDATE(),'$v42',$v27);";
     $sql .= "CALL uqty($v23,($g5-$v25))";
     if (mysqli_multi_query($conn, $sql)) {
         do {

             if ($result = mysqli_store_result($conn)) {
                 while ($row = mysqli_fetch_row($result)) {
                     printf("%s\n", $row[0]);
                 }
                 mysqli_free_result($result);
             }

             if (mysqli_more_results($conn)) {
                 printf("\n");
             }
         } while (mysqli_next_result($conn));
     }

  }
else {
  echo '<script language="javascript">';
  echo 'alert("Product 5 NOT AVAILABLE")';
  echo '</script>';

 $v42="NOT AVAILABLE";
 $v25=$v40=$v26=0;
 $sql = "CALL product($v23,'$v24',$v25,$v26,$v40,CURDATE(),'$v42',$v27);";
 if ($conn->query($sql) === TRUE) {
       }
       $sql="CALL updatedorderid($v7)";
       if ($conn->query($sql) === TRUE) {
             }

}
}
if($flag==1)
{location('../billing.html');}

mysqli_close($conn);
?>
 <!DOCTYPE HTML>
<!--
	Ion by TEMPLATED
	templated.co @templatedco
	Released for free under the Creative Commons Attribution 3.0 license (templated.co/license)
-->
<html>
	<head>
		<title>Accounting Software</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<!--[if lte IE 8]><script src="js/html5shiv.js"></script><![endif]-->
		<script src="js/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-layers.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-xlarge.css" />
		</noscript>
	</head>
	<body id="top">

		<!-- Header -->


		<!-- Banner -->
			<section id="banner">
				<div class="inner">

					<ul class="actions">
						<li><a class="button big special">Thank You!<br/>Please visit again</a></li>

					</ul>
				</div>
			</section>

		<!-- One -->
			<section id="one" class="wrapper style1">
				<div class="container">
					<div class="row">
						<div class="4u">
							<section class="special box">
					<a  href="../index.html">	<i class="icon fa-area-chart major"></i> </a>
								<h1>HOME</h1>

							</section>
						</div>
						<div class="4u">
							<section class="special box">
						<a href= "../billentry.html">		<i class="icon fa-refresh major"></i>  </a>
								<h1>Back To Billing</h3>

							</section>
						</div>
						<div class="4u">
							<section class="special box">
						<a href="../billtab.php">		<i class="icon fa-cog major"></i></a>
					<h1>View Recent Billing</h1>
							</section>
						</div>
					</div>
				</div>
			</section>

		<!-- Two -->
			<section id="two" class="wrapper style2">
				<header class="major">


	</body>
</html>
