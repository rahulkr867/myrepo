<html>
<title>Stock Entry</title>
</html>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//echo'<b>"Your Data has been Stored:"</>'."<br>";
echo '<body style="background-color:silver"></body>';
$v3 =$_POST['a'];
$v7 =$_POST['e'];
$sql = "SELECT p_qty FROM stock WHERE p_id=$v3 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g1=$row["p_qty"];
$v7=$v7+$g1;
$sql = "UPDATE stock SET p_qty='$v7' WHERE p_id='$v3'";

if (mysqli_query($conn, $sql)) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . mysqli_error($conn);
}
if ($conn->query($sql) === TRUE) {
   header('Location:inventory.html');
} else {
  header('Location:index.html');
}




mysqli_close($conn);

?>
