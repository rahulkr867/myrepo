<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    text-align: left;
}
table#t01 {
    width: 100%;
    background-color: #f1f1c1;
}
</style>
</head>
<body>



<table id="t01">
  <tr>
     <th>Product Id</th>
     <th>Product Name</th>
     <th>Product Quantity</th>
     <th>MRP</th>
     <th>Total Cost</th>
     <th>Date</th>
     <th>Out of Stock Status</th>
     <th>Order Id</th>
  </tr>
<?php
   $servername = "localhost";
   $username = "root";
   $password = "";
   $dbname = "db";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn)
  {
    die("Connection failed: " . mysqli_connect_error());
  }
?>
<?php
$sql = "SELECT updatedid FROM orderidupdate WHERE serial=1 ";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result)>0)
while($row = mysqli_fetch_assoc($result))
$g1=$row["updatedid"];
 ?>
<?php

  $sql = "SELECT * FROM order_info WHERE order_id=$g1";
  $result = mysqli_query($conn, $sql);
?>
<?php  if(mysqli_num_rows($result)>0)?>
<?php {
    ?>


   <?php  while($row = mysqli_fetch_assoc($result))
    {?>

        <tr>
    <td><?php  echo $row["product_id"]; ?></td>
    <td><?php echo $row["product_name"]; ?></td>
    <td><?php echo $row["qty"]; ?></td>
    <td><?php echo $row["selling_price"]; ?></td>
    <td><?php echo $row["total"]; ?></td>
    <td><?php echo $row["sell_date"]; ?></td>
    <td><?php echo $row["out of stock status"]; ?></td>
    <td><?php echo $row["order_id"]; ?></td>


 </tr>


   <?php } ?>
  </table>
<?php } ?>

<?php mysqli_close($conn);

?>
<form method="post" action="index.html/"style="position: absolute; top: 550px; right: 45px; width: 100px;height: 25px; text-align:right;">
    <button type="submit">Back to Homepage</button>
</form>

<form method="post" action="billing.html" style="position: absolute; top: 550px; right: 143px; width: 100px;height: 25px; text-align:right;">
   <button type="submit">Back to Billing page</button>
</form>

</body>
</html>
