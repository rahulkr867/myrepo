<head>
<link rel="stylesheet" type="text/css" href="inv.css">
<script src="inv.js"></script>
<style>
.button {
    background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 16px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    cursor: pointer;
}

.button1 {
    background-color: white;
    color: black;
    border: 2px solid #4CAF50;
	}
	.button1:hover {
    background-color: #4CAF50;
    color: white;

}
</style>
</head>
<section> <!--for demo wrap-->
<h1>Stock/Inventory </h1>
<div  class="tbl-header">
<table cellpadding="0" cellspacing="0" border="0">
  <thead>
  <tr>
    <th>Product Id</th>
    <th>Product Name</th>
    <th>Cost price</th>
    <th>Selling price</th>
    <th>Profit</th>
    <th>Purchase date</th>
    <th>Quantity</th>

  </tr>
  </thead>
</table>
</div>
<div  class="tbl-content">
<table cellpadding="0" cellspacing="0" border="0">
  <tbody>
  <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db";


$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>
    <?php

$sql = "SELECT * FROM stock ";
$result = mysqli_query($conn, $sql);
    ?>
<?php  if(mysqli_num_rows($result)>0)?>
<?php {
    ?>


   <?php  while($row = mysqli_fetch_assoc($result))
    {?>
     <?php   if($row["p_id"]){?>
        <tr>
    <td><?php  echo $row["p_id"]; ?></td>
    <td><?php echo $row["p_name"]; ?></td>
    <td><?php echo $row["cost price"]; ?></td>
    <td><?php echo $row["selling price"]; ?></td>
  <td><?php echo $row["net_profit"]; ?></td>
  <td><?php echo $row["purchase_date"]; ?></td>
  <td><?php echo $row["p_qty"]; ?></td>

  <?php }?>
 </tr>


   <?php } ?>

</tbody>
 </table>
<?php } ?>

<?php mysqli_close($conn);

?>

</div>
</section>
<div style="padding-left:500px;">

<a href="index.html"><button class="button button1" >Homepage</button></a>
<a href="inventory.html"><button class="button button1">Back to Stock</button></a>
</div>
</body>
</html>
